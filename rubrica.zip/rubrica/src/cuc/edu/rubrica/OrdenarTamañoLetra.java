package cuc.edu.rubrica;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.util.Scanner;
// generar un nuevo archivo donde primero se encuentren todas las palabras con una letra, 
// luego las de dos letras, luego las de tres letras y así sucesivamente hasta que se agote el texto. 
// Las palabras no tienen por qué estar ordenadas alfabéticamente.
public class OrdenarTamañoLetra {
    private File archivoObjeto;

    public OrdenarTamañoLetra(File archivoObjeto) {
        this.archivoObjeto = archivoObjeto;
    }
    
    //metodo tamaño
    public File metodoOrdenarTamañoPalabra() throws FileNotFoundException {
        Scanner scanner = new Scanner(archivoObjeto);
        int contador = 0;
        File archivo = new File("letra.txt");
        String s = scanner.nextLine();
        String[] palabras = s.split(" ");
        contador += palabras.length;
        for (int i = 0; i < palabras.length; i++) {
            int tamaño = palabras[i].length();
            System.out.println("Longitud de una cadena es:" + tamaño);
            try {
                File letras = new File("letra.txt");
                FileWriter escribir = new FileWriter(letras, true);
                escribir.write(tamaño + " = " + palabras[i]);
                escribir.write("\n");
                escribir.close();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        return archivo;
    }

}

