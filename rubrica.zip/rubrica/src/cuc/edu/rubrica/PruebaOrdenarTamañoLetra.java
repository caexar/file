package cuc.edu.rubrica;

import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class PruebaOrdenarTamañoLetra {
    public static void main(String[] args) {
        
           try {
            File texto = new File("texto.txt");            
            OrdenarTamañoLetra orden = new OrdenarTamañoLetra(texto);
            File ordenado = orden.metodoOrdenarTamañoPalabra();
            System.out.println("Programa finalizado, guardado en: "+ordenado);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PruebaOrdenarTamañoLetra.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error");
        }
        
    }
    
}
